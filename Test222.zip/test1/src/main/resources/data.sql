INSERT INTO Member2(name, password, email) VALUES('James', '1234', 'james@email.com');
INSERT INTO Member2(name, password, email) VALUES('Hans', '1234', 'hans@email.com');
INSERT INTO Member2(name, password, email) VALUES('Sumi', '1234', 'sumi@email.com');