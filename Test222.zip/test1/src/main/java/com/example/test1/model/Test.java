package com.example.test1.model;

public class Test {
	private String productNo;
	private String productName;
	private String productPrice;
}
